package com.reddy.dto.auth;


public record JwtResponse(String token) {
}
