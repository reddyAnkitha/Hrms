package com.reddy.enums;

public enum PaymentStatus {
    PENDING,
    APPROVED,
    PAID,
    PROCESSED,
    REJECTED
}
