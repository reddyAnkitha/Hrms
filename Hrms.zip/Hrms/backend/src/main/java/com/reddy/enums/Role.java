package com.reddy.enums;

public enum Role {
    ADMIN, MANAGER, EMPLOYEE
}

