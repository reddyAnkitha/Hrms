package com.reddy.enums;

public enum DocumentType {
    ID_PROOF, ADDRESS_PROOF, DEGREE_CERTIFICATE, PAYSLIP
}
