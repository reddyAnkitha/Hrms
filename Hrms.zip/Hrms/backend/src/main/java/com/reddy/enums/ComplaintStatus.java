package com.reddy.enums;

public enum ComplaintStatus {
    OPEN, IN_PROGRESS, RESOLVED
}
