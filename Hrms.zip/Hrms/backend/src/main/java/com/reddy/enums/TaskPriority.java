package com.reddy.enums;

public enum TaskPriority {
    LOW, MEDIUM, HIGH
}
