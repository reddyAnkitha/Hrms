package com.reddy.dto.auth;

public record LoginRequest(String username, String password) {}

