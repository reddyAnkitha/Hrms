package com.reddy.enums;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
