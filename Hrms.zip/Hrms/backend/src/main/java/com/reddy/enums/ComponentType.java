package com.reddy.enums;

public enum ComponentType {
    EARNING,
    DEDUCTION
}
