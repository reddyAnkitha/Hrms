package com.reddy.enums;

public enum TaskStatus {
    NOT_STARTED, IN_PROGRESS, COMPLETED
}