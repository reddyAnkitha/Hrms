package com.reddy.enums;

public enum VerificationStatus {
    PENDING, VERIFIED, REJECTED
}
